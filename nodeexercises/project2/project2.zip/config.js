import { config } from "dotenv";
config();
export const port = process.env.PORT;

// import { config } from "dotenv";
// config();
// export const atlas = process.env.DBURL;
// export const appdb = process.env.DB;
// export const rawdata = process.env.ISOCOUNTRIES;
// export const alertJson = process.env.GOCALERTS;
// export const userobjects = process.env.ALERTCOLLECTION;
// export const port = process.env.PORT;
// export const graphql = process.env.GRAPHQLURL;
// export const advisoryobjects = process.env.ADVISORYCOLLECTION;
// export const collection = process.env.COLLECTION;
